let fs = require("fs");
let data = fs.readFileSync(0, "utf-8");
let idx = 0;
data = data.split("\n");

function readLine() {
  idx++;
  return data[idx - 1];
}

// -------- Do NOT edit anything above this line ----------

let testCases = parseInt(readLine());

for (let i = 0; i < testCases; i++) {
  let input = readLine().trim().split(",");

  let map = new Object();

  let key = 0;
  let value = 1;
  while (key < input.length && value < input.length) {
    map[input[key]] = input[value];
    key += 2;
    value += 2;
  }

  console.log(map);
}

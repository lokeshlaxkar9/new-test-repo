let fs = require("fs");
let data = fs.readFileSync(0, "utf-8");
let idx = 0;
data = data.split("\n");

function readLine() {
  idx++;
  return data[idx - 1];
}

// -------- Do NOT edit anything above this line ----------

let testCases = parseInt(readLine());

for (let i = 0; i < testCases; i++) {
  let input = readLine().trim().split(" ");
  console.log(driveCheck(input[0], input[1], input[2]));
}

function driveCheck(lisence, tired, sober) {
  if (lisence === "true") {
    if (tired === "true" || sober === "false") {
      return "You shouldn't drive";
    }
    return "You can drive";
  }

  return "You cannot drive";
}
